export default function Home() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-rose-50 px-4">
      <div className="max-w-md w-full text-center space-y-4">
        <h1 className="text-3xl font-bold text-rose-900">웨딩폼</h1>
        <p className="text-rose-700">
          결혼식 이벤트 영상을 QR로 하객에게 판매하고 이벤트를 제공하는 플랫폼
        </p>
        <p className="text-sm text-rose-500">개발 서버 · localhost:3046</p>
      </div>
    </main>
  );
}
