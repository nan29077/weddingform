# 웨딩폼

결혼식 이벤트 영상을 QR로 하객에게 판매하고 이벤트를 제공하는 플랫폼.

## 실행 (Windows PowerShell)

```powershell
cd "E:\프로젝트\웨딩폼"
npm install
npm run dev
```

미리보기: http://localhost:3046

## 스택
- Next.js 15 (App Router) · TypeScript · Tailwind CSS v4
