import Link from "next/link";
import { notFound } from "next/navigation";
import { Logo } from "@/components/site/Logo";
import { ROLES, ROLE_KEYS, type RoleKey } from "@/lib/roles";

export function generateStaticParams() {
  return ROLE_KEYS.map((role) => ({ role }));
}

export default async function DashboardPage({ params }: { params: Promise<{ role: string }> }) {
  const { role } = await params;
  if (!ROLE_KEYS.includes(role as RoleKey)) notFound();
  const info = ROLES[role as RoleKey];

  return (
    <div className="min-h-screen bg-mist">
      <header className="border-b border-line bg-white">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <Logo />
          <div className="flex items-center gap-3 text-sm">
            <span className="rounded-full bg-peony-soft px-3 py-1 font-medium text-peony-deep">{info.label}</span>
            <Link href="/login" className="text-ink-soft hover:text-ink">
              로그아웃
            </Link>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
        <h1 className="font-display text-3xl text-ink">{info.label} 관리 페이지</h1>
        <p className="mt-3 text-ink-soft">{info.desc} 화면이 이곳에 들어갈 예정입니다.</p>
        <div className="mt-10 rounded-3xl border border-dashed border-ink/20 bg-white p-10 text-center text-ink-soft">
          화면 준비 중입니다
        </div>
      </main>
    </div>
  );
}
