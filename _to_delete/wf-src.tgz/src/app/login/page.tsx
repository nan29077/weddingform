import type { Metadata } from "next";
import { Logo } from "@/components/site/Logo";
import { QrMock } from "@/components/landing/QrMock";
import { LoginForm } from "./LoginForm";

export const metadata: Metadata = {
  title: "로그인 | 웨딩폼",
};

export default function LoginPage() {
  return (
    <div className="grid min-h-screen md:grid-cols-[1fr_1.05fr]">
      <aside className="relative hidden overflow-hidden bg-ink p-12 text-white md:flex md:flex-col md:justify-between">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -bottom-32 -left-32 h-[420px] w-[420px] rounded-full bg-peony/30 blur-3xl"
        />
        <Logo tone="light" />
        <div className="relative">
          <div className="w-44 rotate-[-4deg] rounded-3xl bg-white p-4 text-ink shadow-2xl">
            <QrMock className="block h-auto w-full" />
          </div>
          <p className="mt-10 max-w-sm font-display text-[2rem] leading-[1.35]">
            오늘도 누군가의 결혼식이 하객의 휴대폰에 남고 있습니다
          </p>
        </div>
        <p className="relative text-sm text-white/50">주식회사 이십세기 소년들</p>
      </aside>

      <main className="flex items-center justify-center px-4 py-12 sm:px-8">
        <div className="w-full max-w-[420px]">
          <div className="md:hidden">
            <Logo />
          </div>
          <h1 className="mt-8 font-display text-[2rem] text-ink md:mt-0">관리 페이지 로그인</h1>
          <p className="mt-2 text-ink-soft">신랑신부, 영업 관리자, 최고 관리자 계정으로 로그인합니다.</p>
          <LoginForm />
        </div>
      </main>
    </div>
  );
}
